
import java.util.*;
import java.sql.*;

/**
*  @Course: ISTE-330/722Database Connectivity and Access final project
*  @Task: Faculty Research Database
*  @Authors: Roman Rogic Cvinar, Dorde Vulevic, Victor Chindemi, Jonathan Coney
*  @Date: 06/05/23
*/

public class Connect {

// Attributes
   public Statement stmt = null;
   public ResultSet rs = null;
   public Connection conn = null;
   public PreparedStatement ps = null;
   public String user = "root";
   public String pass = "romorogic123";
   public String dbase = "FacResearchDB";
   
// Constructor
   public Connect() {
      conn = null;
      connect();
   
   }
   
// Connection to database
   public boolean connect()  {
      try {
         Class.forName("com.mysql.jdbc.Driver");
         conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/" + dbase + "?autoReconnect=true&useSSL=false",user,pass);
         System.out.println("System Connected");
         return true;
         
      }catch(SQLException e) {
         System.out.println("Error: " + e.getMessage());
         return false;
         
      }catch(ClassNotFoundException ce) {
         System.out.println("Error: " + ce.getMessage());
         return false;
      }
   }
    
//Close connection method
   public boolean close() {
      try{
         conn.close();
         return true;
      }catch(Exception e) {
         return false;
      }
   }
   
// Faculty Login
   public boolean login(String email, String pass) {
      try{
         ps = conn.prepareStatement("SELECT * FROM faculty WHERE email = ? AND password =?");
         ps.setString(1,email);
         ps.setString(2,pass);

         rs = ps.executeQuery();
      
         if(rs.next()) {

               return true;
            } else { 
               return false; 
            }
         
         
      }catch(Exception e) {
         return false;
      }
   }
   
// Display paper titles
   public ArrayList<String> getTitles() {
      ArrayList<String> title = new ArrayList<>();
   
      try{
         ps = conn.prepareStatement("SELECT id,title FROM papers");
         rs = ps.executeQuery();
      
         while (rs.next()){
            title.add("\nPaper "+rs.getString(1)+".   "+rs.getString(2));
         }
         
      
      }catch(Exception e){
         e.getMessage();
      }
      return title;   
   }
   
// Find paper by keyword
   public ArrayList<String> searchByKey(String keyword){
   
      ArrayList<String> paperList = new ArrayList<>();
      try{
      
         ps = conn.prepareStatement("SELECT id FROM paper_keywords WHERE keyword=?");
         ps.setString(1,keyword);
         rs = ps.executeQuery();
         while(rs.next()){
            int keyId = rs.getInt("id");
            ps = conn.prepareStatement("SELECT * FROM papers WHERE id=?");
            ps.setInt(1, keyId);
            rs = ps.executeQuery();
            if(rs.next()){
               paperList.add("Paper "+rs.getString(1) + "\nTitle:" + rs.getString(2) + "\n\nAbstract: " + rs.getString(3) + "\n\nCitation: " + rs.getString(4));
               return paperList;
            }
         }
         return null;
      }catch(SQLException e){
         System.out.println(e.getMessage());
         return null;
      }
      
   }
      
// Adding new paper
   public boolean addPaper(int id, String title, String abst, String citation){
   
      try{            
         ps = conn.prepareStatement("INSERT INTO papers (id, title, abstract, citation) VALUES (?,?,?,?)");
         ps.setInt(1,id);
         ps.setString(2,title);
         ps.setString(3,abst);
         ps.setString(4,citation);
         ps.executeUpdate();
         System.out.println("success");
         return true;
      }catch(SQLException e){
         System.out.println(e);
         return false;
      }
   }
   
// Update paper title
   public boolean updatePaperTitle(int id, String title){
      try{
         ps = conn.prepareStatement("UPDATE papers SET title=? WHERE id=?");
         ps.setString(1,title);
         ps.setInt(2,id);
         ps.executeUpdate();
         return true;
      }catch(SQLException e){
         System.out.println(e);
         return false;
      }
   }
   
// Update paper abstract
   public boolean updatePaperAbstract(int id, String abst   ){
      try{
         ps = conn.prepareStatement("UPDATE papers SET abstract=? WHERE id=?");
         ps.setString(1,abst);
         ps.setInt(2,id);
         ps.executeUpdate();
         return true;
      }catch(SQLException e){
         System.out.println(e);
         return false;
      }
   }
   
// Update paper citation
   public boolean updatePaperCitation(int id, String citation){
      try{
         ps = conn.prepareStatement("UPDATE papers SET citation=? WHERE id=?");
         ps.setString(1,citation);
         ps.setInt(2,id);
         ps.executeUpdate();
         return true;
      }catch(SQLException e){
         System.out.println(e);
         return false;
      }
   }

   
// Delete paper by id
   public boolean deletePaper(int id){
      try{
         ps = conn.prepareStatement("DELETE FROM paper_keywords WHERE id=?");
      
         ps.setInt(1,id);
         ps.executeUpdate();
         ps = conn.prepareStatement("DELETE FROM papers WHERE id=?");
         ps.setInt(1,id);
         ps.executeUpdate();
         return true;
      }catch(SQLException e){
         System.out.println(e);
         return false;
      }
   }
   
// Select all keywords
   public ArrayList<String> key(){
   ArrayList<String> keyList = new ArrayList<>();
      try{
         ps = conn.prepareStatement("SELECT * FROM paper_keywords");
         rs = ps.executeQuery();
         while(rs.next()){
         
            System.out.println(rs.getString(1)+".  "+rs.getString(2));
            keyList.add(rs.getString(1)+".  "+rs.getString(2) + "\n");
            
         }      
      }catch(SQLException e){
         System.out.println(e);
         
      }
      return keyList;
   }
   
// Add keywords
   public boolean addKeyword(int id, String key){
      try{
         ps = conn.prepareStatement("INSERT INTO paper_keywords (id, keyword) VALUES(?,?)");
         ps.setInt(1,id);
         ps.setString(2,key);
         ps.executeUpdate();
         return true;
      }catch(SQLException e){
         System.out.print(e);
         return false;
      }
   }
}     