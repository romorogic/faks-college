/**
*  @Course: ISTE-330/722Database Connectivity and Access final project
*  @Task: Faculty Research Database
*  @Authors: Roman Rogic Cvinar, Dorde Vulevic, Victor Chindemi, Jonathan Coney
*  @Date: 06/05/23
*/

public class BusinessLayer {

// Attributes
   public int id;
   public String title;
   public String abstraction;
   public String citation;
   public String keyword;

// Constructor #1
   public BusinessLayer(){}
   
// Constructor #2
   public BusinessLayer(int id, String title, String abstraction, String citation) {
      this.id = id;
      this.title = title;
      this.abstraction = abstraction;
      this.citation = citation;
   }
   
// Constructor #3
   public BusinessLayer(int id, String keyword) {
      this.id = id;
      this.keyword = keyword;
   }
   
// Accessors & Mutators
   public int getId() {
      return id;
   }
   
   public void setId(int id) {
      this.id = id;
   }
   
   public String getTitle() {
      return title;
   }
   
   public void setTitle(String title) {
      this.title = title;
   }
   
   public String getAbstraction() {
      return abstraction;
   }
   
   public void setAbstracton(String abstraction) {
      this.abstraction = abstraction;
   }
   
   public String getCitation() {
      return citation;
   }
   
   public void setCitation(String citation) {
      this.citation = citation;
   }
   
   public String getKeyword() {
      return keyword;
   }
   
   public void setKeyword(String keyword) {
      this.keyword = keyword;
   }
   
}