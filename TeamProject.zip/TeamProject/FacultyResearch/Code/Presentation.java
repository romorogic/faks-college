
/**
*  @Course: ISTE-330/722Database Connectivity and Access final project
*  @Task: Faculty Research Database
*  @Authors: Roman Rogic Cvinar, Dorde Vulevic, Victor Chindemi, Jonathan Coney
*  @Date: 06/05/23
*/

import javafx.application.Application;
import javafx.event.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.control.Alert.*;
import javafx.scene.layout.*;
import javafx.scene.layout.BorderPane;
import javafx.stage.*;
import javafx.geometry.*;
import java.util.ArrayList;

public class Presentation extends Application implements EventHandler<ActionEvent> {

   // Set Stage, Scene and VBox
   Stage stage = null;
   Scene scene = null;
   VBox root = new VBox(8);

   // Faculty 
   private Connect cl = new Connect();
   private TextField tfEmail = new TextField();

   private Label lblEmail = new Label("Email Address");
   private PasswordField psField = new PasswordField();

   private Label lblPass = new Label("Password");
   private TextArea tArea = new TextArea();
   private Button btnSearch = new Button("Search");
   private Button btnEdit = new Button("Update/Add Paper");
   private Button btnDelete = new Button("Delete");
   private Button btnKey = new Button("List Keywords");

   
   private TextField tfId = new TextField();
   private TextField tfTitle = new TextField();
   private TextArea tfAbstraction = new TextArea();
   private TextField tfCitaton = new TextField();
   private TextField tfKey = new TextField();

   private Label lblID = new Label("ID:");
   private Label lblTitle = new Label("Title:");
   private Label lblAbstraction = new Label("Abstract:");
   private Label lblCitation = new Label("Citation:");
   private Label lblKey = new Label("Keyword:");

   // Update/Add widgets
   private Button btnUpdate = new Button("Update");
   private Button btnAdd = new Button("Add New");

   // ShowTitles widgets
   private Button btnBack = new Button("Show Titles");
   private Button btnReturn = new Button("Show titles");

   // Search widgets
   private TextField tfSearch = new TextField();
   private Label lblSearch = new Label("Search by keyword");

   // Deletion widgets
   private TextField tfDelete = new TextField();
   private Label lblDelete = new Label(" Delete by Paper ID");

   // UI view buttons
   private Button a = new Button("LOGIN");
   private Button b = new Button("Browse as student");
   private Button c = new Button("Browse as public");

   private Button home = new Button(".");
   private Button credits = new Button("Credits");

   // Start method
   public void start(Stage _stage) {
      stage = _stage;
      stage.setTitle("Faculty Research Database");

      FlowPane mid = new FlowPane();
      GridPane gridPane = new GridPane();
      gridPane.setAlignment(Pos.CENTER);
      gridPane.setHgap(10);
      gridPane.setVgap(10);
      gridPane.setPadding(new Insets(100, 25, 25, 25));

      gridPane.add(lblEmail, 0, 1);
      gridPane.add(tfEmail, 0, 2);
      gridPane.add(lblPass, 0, 3);
      gridPane.add(psField, 0, 4);

      // Styling buttons & adding background and home icon
      lblEmail.setStyle("-fx-text-fill:black;");
      lblPass.setStyle("-fx-text-fill:black;");
      root.setStyle("-fx-background-image:url(assets/background.png);-fx-background-size: cover;");
      a.setStyle(
            "-fx-cursor: hand; -fx-background-color:black;-fx-background-radius:100;-fx-text-fill:white;-fx-font-weight: bold;-fx-border-color:#ffffff;-fx-border-radius:100;");
      b.setStyle(
            "-fx-cursor: hand; -fx-background-color:black;-fx-background-radius:100;-fx-text-fill:#ffffff;-fx-border-color:#ffffff;-fx-border-radius:100;");
      c.setStyle(
            "-fx-cursor: hand; -fx-background-color:black;-fx-background-radius:100;-fx-text-fill:#ffffff;-fx-border-color:#ffffff;-fx-border-radius:100;");
      btnSearch.setStyle(
            "-fx-cursor: hand; -fx-background-color:#ffffff;-fx-background-radius:100;-fx-text-fill:grey;-fx-border-color:grey;-fx-border-radius:100;");
      btnDelete.setStyle(
            "-fx-cursor: hand; -fx-background-color:#ffffff;-fx-background-radius:100;-fx-text-fill:grey;-fx-border-color:grey;-fx-border-radius:100;");
      btnEdit.setStyle(
            "-fx-cursor: hand; -fx-background-color:white;-fx-background-radius:100;-fx-text-fill:grey;-fx-border-color:grey;-fx-border-radius:100;");
      btnUpdate.setStyle(
            "-fx-cursor: hand; -fx-background-color:#ffffff;-fx-background-radius:100;-fx-text-fill:grey;-fx-border-color:grey;-fx-border-radius:100;");
      btnAdd.setStyle(
            "-fx-cursor: hand; -fx-background-color:white;-fx-background-radius:100;-fx-text-fill:grey;-fx-border-color:grey;-fx-border-radius:100;");
      btnKey.setStyle(
            "-fx-cursor: hand; -fx-background-color:#F5F5DC;-fx-background-radius:100;-fx-text-fill:grey;-fx-border-color:grey;-fx-border-radius:100;");
      home.setStyle(
            "-fx-cursor: hand; -fx-background-image: url(assets/home.png); -fx-background-size: 30px 30px; -fx-background-repeat: no-repeat; -fx-background-position: center; -fx-background-color:#F5F5DC;-fx-text-fill:grey; ");
      credits.setStyle(
            "-fx-cursor: hand; -fx-background-color:#F5F5DC;-fx-background-radius:100;-fx-text-fill:grey;-fx-border-color:grey;-fx-border-radius:100;");
      btnBack.setStyle(
            "-fx-cursor: hand; -fx-background-color:#F5F5DC;-fx-background-radius:100;-fx-text-fill:grey;-fx-border-color:grey;-fx-border-radius:100;");
      btnReturn.setStyle(
            "-fx-cursor: hand; -fx-background-color:#F5F5DC;-fx-background-radius:100;-fx-text-fill:grey;-fx-border-color:grey;-fx-border-radius:100;");

      home.setPrefWidth(30);
      home.setPrefHeight(30);

      gridPane.add(a, 0, 6);
      gridPane.add(b, 0, 8);
      gridPane.add(c, 0, 9);
      a.setPadding(new Insets(5, 55, 5, 55));
      b.setPadding(new Insets(5, 25, 5, 25));
      c.setPadding(new Insets(5, 29, 5, 29));

      gridPane.setAlignment(Pos.CENTER);
      mid.setAlignment(Pos.CENTER);

      mid.setPadding(new Insets(100, 0, 0, 0));

      /*
      * First EvenHandler
      * Allows user to select a view of faculty, student and public screens
      **/
      EventHandler<ActionEvent> event = new EventHandler<ActionEvent>() {

         public void handle(ActionEvent event) {

            String buttonFunct = ((Button) event.getSource()).getText();

            switch (buttonFunct) {
               
               case "LOGIN":
                  doLogin();
                  break;
               
               case "Browse as student":
                  studentScreen();

                  break;
               
               case "Browse as public":
                  studentScreen();

                  break;

            }
         }
      }; // switch over

      a.setOnAction(event);
      b.setOnAction(event);
      c.setOnAction(event);

      root.getChildren().addAll(mid, gridPane);
      scene = new Scene(root, 800, 600);

      stage.setScene(scene);
      stage.show();

   } // Start method over

   /* 
   * Second EventHandler
   * Events for all buttons under faculty use and student/public
   * Delete, Add, Update, Select Keyword, ListKLeyword, ShowTitles and Home button
   **/
   
   public void handle(ActionEvent evt) {

      Button btn = (Button) evt.getSource();

      switch (btn.getText()) {
         //1
         case "Delete":
            doDelete();
            break;
         //2      
         case "Update/Add Paper":
            doEdit();
            break;
         //3
         case "Search":
            doSearch();
            break;
         //4
         case ".":
            doHome();
            break;
         //5
         case "Credits":
            Alert creditsInfo = new Alert(AlertType.INFORMATION);
            creditsInfo.setTitle("INFORMATION");
            creditsInfo.setHeaderText("The team that has done this project:");
            creditsInfo.setContentText("Roman Rogic Cvinar \nDorde Vulevic \nViktor Chindemi \nJonathan Coney");
            creditsInfo.showAndWait();
            break;
         //6
         case "Update":
            doUpdate();
            break;
         //7
         case "Add New":
            doAdd();
            break;
         //8
         case "List Keywords":
            Alert keyInfo = new Alert(AlertType.INFORMATION);
            keyInfo.setTitle("INFORMATION");
            keyInfo.setHeaderText("List of Keywords");
            keyInfo.setContentText(String.valueOf(cl.key()).replace("[", "").replace("]", "").replace(",", ""));
            keyInfo.showAndWait();
            break;
         //9
         case "Show Titles":
            tArea.clear();
            studentScreen();
            break;
         //10
         case "Show titles":
            tArea.clear();
            facultyScreen();
            break;
         //11
         default:
            System.out.println("Well it seems some of the buttons doesn't have it's assigned case -- ");

      }
   } // Button EventHandler over

   // Faculty login UI view
   public void facultyScreen() {

      // Style
      root.setStyle("-fx-background-color:#ffffff;");
      tArea.setStyle("-fx-control-inner-background:#e6e6e6;-fx-border-color:grey;");

      // Clearing VBox for new elements
      root.getChildren().clear();

      // Style
      tArea.setPrefHeight(400);
      tArea.setWrapText(true);
      tArea.setEditable(false);

      displayTitles();
      BorderPane top = new BorderPane();
      top.setRight(credits);
      top.setLeft(home);
      top.setStyle("-fx-background-color:#F5F5DC;-fx-border-color:grey;");
      top.setPadding(new Insets(25, 15, 25, 15));

      home.setOnAction(this);
      credits.setOnAction(this);

      FlowPane mid = new FlowPane();
      mid.setPadding(new Insets(5, 0, 0, 0));

      mid.setAlignment(Pos.TOP_CENTER);
      mid.setHgap(60);
      mid.getChildren().addAll(lblSearch, tfSearch, btnSearch);
      btnSearch.setPadding(new Insets(5, 25, 5, 25));

      btnSearch.setOnAction(this);

      // Adding new panes & styling
      FlowPane fp3 = new FlowPane();
      FlowPane fp2 = new FlowPane();

      fp2.setAlignment(Pos.BOTTOM_CENTER);
      fp2.setPadding(new Insets(20, 0, 20, 0));
      fp2.setHgap(60);
      fp2.getChildren().addAll(lblDelete, tfDelete, btnDelete);
      btnDelete.setPadding(new Insets(5, 25, 5, 25));

      btnDelete.setOnAction(this);

      fp3.setAlignment(Pos.BOTTOM_CENTER);
      fp3.setPadding(new Insets(20, 0, 20, 0));
      fp3.getChildren().addAll(btnEdit);
      btnEdit.setPadding(new Insets(5, 45, 5, 45));

      btnEdit.setOnAction(this);

      FlowPane bot = new FlowPane();
      bot.setVgap(1);
      bot.setHgap(10);

      bot.setAlignment(Pos.BOTTOM_CENTER);

      bot.setPadding(new Insets(25, 0, 25, 0));
      bot.setStyle("-fx-background-color:#F5F5DC;-fx-border-color:grey;");
      bot.getChildren().add(btnKey);
      bot.setVgap(10);

      btnKey.setPadding(new Insets(5, 55, 5, 55));
      btnKey.setOnAction(this);

      btnReturn.setPadding(new Insets(5, 55, 5, 55));
      btnReturn.setOnAction(this);

      bot.getChildren().add(btnReturn);

      // Displaying all elements
      root.getChildren().addAll(top, tArea, mid, fp2, fp3, bot);

   }

   // Login UI view
   public void doLogin() {
      String em = tfEmail.getText();
      String pw = psField.getText();

      // Checking login credentials
      if (cl.login(em, pw)) {
         facultyScreen();

         // ERROR if invalid credentials input
      } else {
         System.out.println("Invalid Credentials!");
         Alert alert = new Alert(AlertType.ERROR);
         alert.setTitle("Failed to Login");
         alert.setHeaderText("SpellCheck you input again!");
         alert.setContentText("You entered invalid credentials \nPlease check your email & password");
         alert.showAndWait();
      }
   } // Login view over

   // Student/Public login UI view
   public void studentScreen() {

      // Style & buttons
      root.setStyle("-fx-background-color:#ffffff;");
      tArea.setStyle("-fx-control-inner-background:#e6e6e6;");

      root.getChildren().clear();

      tArea.setPrefHeight(400);
      tArea.setWrapText(true);
      tArea.setEditable(false);

      displayTitles();
      BorderPane top = new BorderPane();
      top.setRight(credits);
      top.setLeft(home);
      top.setStyle("-fx-background-color:#F5F5DC;-fx-border-color:grey;");
      top.setPadding(new Insets(25, 15, 25, 15));
      home.setOnAction(this);
      credits.setOnAction(this);

      FlowPane mid = new FlowPane();
      mid.setAlignment(Pos.TOP_CENTER);
      mid.setPadding(new Insets(20, 0, 20, 0));
      mid.setHgap(60);
      mid.getChildren().addAll(lblSearch, tfSearch, btnSearch);
      btnSearch.setOnAction(this);

      FlowPane bot = new FlowPane();
      bot.setAlignment(Pos.BOTTOM_CENTER);
      bot.setVgap(1);
      bot.setHgap(10);

      bot.setPadding(new Insets(25, 0, 25, 0));
      bot.setStyle("-fx-background-color:#F5F5DC;-fx-border-color:grey;");
      bot.getChildren().add(btnKey);

      btnKey.setPadding(new Insets(5, 55, 5, 55));

      btnKey.setOnAction(this);
      btnBack.setPadding(new Insets(5, 55, 5, 55));
      btnBack.setOnAction(this);

      bot.getChildren().add(btnBack);

      // Displaying all elements
      root.getChildren().addAll(top, tArea, mid, bot);
      stage.show();

   } // TitleScreen over

   // dsplayTitles for papers to show in textarea 
   private void displayTitles() {
      ArrayList<String> papers = cl.getTitles();
      for (String paper : papers) {
         tArea.appendText("" + paper);
         tArea.appendText("\n\n");
      }
   }

   /* 
   * doSearch method for keywordsa
   * If the user inputs wrong keyword there will be alert prompted    
   * If the keyword is correct the paper with the keywords id will be opened
   **/ 
   
   public void doSearch() {
      if (cl.searchByKey(tfSearch.getText()) == null) {
         Alert alert = new Alert(AlertType.ERROR);
         alert.setTitle("Keyword Message");
         alert.setHeaderText("Invalid input!");
         alert.setContentText("Please enter a valid keyword.");
         alert.showAndWait();
      } else {

         tArea.setText("" + cl.searchByKey(tfSearch.getText()));
      }
   }

   // doDelete method whch deletes the papers and coresponding keywords based on id
   public void doDelete() {
      int number = Integer.parseInt(tfDelete.getText());

      cl.deletePaper(number);
      // When deleted updates the textarea without it
      tArea.clear();
      displayTitles();
   }

   // doEdit allows paper updates
   public void doEdit() {
      root.getChildren().clear();

      // Style & buttons
      BorderPane top = new BorderPane();
      top.setRight(credits);
      top.setLeft(home);
      top.setStyle("-fx-background-color:#F5F5DC;-fx-border-color:grey;");
      top.setPadding(new Insets(25, 15, 25, 15));
      home.setOnAction(this);
      credits.setOnAction(this);

      GridPane grp = new GridPane();
      grp.setAlignment(Pos.CENTER);
      grp.setHgap(10);
      grp.setVgap(10);
      grp.setPadding(new Insets(25, 25, 25, 25));

      grp.add(lblID, 0, 1);
      grp.add(tfId, 1, 1);
      grp.add(lblTitle, 0, 2);
      grp.add(tfTitle, 1, 2);
      grp.add(lblAbstraction, 0, 3);
      grp.add(tfAbstraction, 1, 3);
      grp.add(lblCitation, 0, 4);
      grp.add(tfCitaton, 1, 4);
      grp.add(lblKey, 0, 5);
      grp.add(tfKey, 1, 5);

      tfAbstraction.setPrefHeight(200);
      tfAbstraction.setPrefWidth(200);

      GridPane gp = new GridPane();

      gp.setAlignment(Pos.TOP_CENTER);
      gp.setHgap(20);
      gp.add(btnAdd, 1, 1);
      gp.add(btnUpdate, 2, 1);

      btnAdd.setPadding(new Insets(5, 30, 5, 30));
      btnUpdate.setPadding(new Insets(5, 30, 5, 30));

      btnAdd.setOnAction(this);
      btnUpdate.setOnAction(this);

      FlowPane bot = new FlowPane();
      bot.setAlignment(Pos.BOTTOM_CENTER);

      bot.setPadding(new Insets(25, 0, 25, 0));
      bot.setStyle("-fx-background-color:#F5F5DC;-fx-border-color:grey;");

      btnReturn.setPadding(new Insets(5, 55, 5, 55));
      btnReturn.setOnAction(this);

      bot.getChildren().add(btnReturn);

      // Displaying all elements
      root.getChildren().addAll(top, grp, gp, bot);

   } // doEdit over

   // doAdd for new paper creation
   public void doAdd() {
      int num1 = Integer.parseInt(tfId.getText());
      String name = tfTitle.getText();
      String content = tfAbstraction.getText();
      String desc = tfCitaton.getText();
      String ky = tfKey.getText();

      cl.addPaper(num1, name, content, desc);

      cl.addKeyword(num1, ky);

   }

   // doUpdate for paper updates
   public void doUpdate() {
      int num1 = Integer.parseInt(tfId.getText());

      if (tfTitle.getText() != null) {
         cl.updatePaperTitle(num1, tfTitle.getText());
      }
      if (tfAbstraction.getText() != null) {
         cl.updatePaperAbstract(num1, tfAbstraction.getText());
      }
      if (tfCitaton.getText() != null) {
         cl.updatePaperCitation(num1, tfCitaton.getText());
      }
      if (tfKey.getText() != null) {
         cl.addKeyword(num1, tfKey.getText());
      }
   }

  // doHome returns user back to login UI view
   public void doHome() {
      try {
         root.getChildren().clear();
         tArea.clear();
         start(stage);
      } catch (Exception e) {
         e.getMessage();
      }
   }
}