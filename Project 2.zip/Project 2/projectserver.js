// projectserver.js
import express from 'express'; //Express.js for http requests
import cors from 'cors'; // Enabeling cors with cors import
import pkg from 'axios';// Axios for request made on external services
const { get } = pkg; //Axios get function for the request

//Creating Express app with Port constant
const app = express(); 
const PORT = 3000;

//app will use cors
app.use(cors());

//route to access the server page
app.get('/', (req, res) => {
    res.send('Welcome to the server!');
});

//request to pull the feed from the given site
app.get('/rss', async (req, res) => {
    try {
        const response = await get('https://www.gameinformer.com/rss.xml'); //rss feed url 
        res.send(response.data);
    } catch (error) {
        console.error('Error fetching RSS feed:', error.message);
        res.status(500).send('Internal Server Error');
    }
});

//Server starts on the assigned port
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
